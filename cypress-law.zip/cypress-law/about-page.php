<?php
/*
Template Name: About Page
*/
get_header();
?>

<main class="about-page">
    <section class="about-header">
        <h1>About Cypress Law Group</h1>
        <p>Dedicated. Strategic. Client-Focused.</p>
    </section>

    <section class="about-content">
        <p>
            Cypress Law Group was founded on the principle that legal representation should be both effective and approachable. Our attorneys are experienced professionals specializing in family law, civil litigation, and small business advisory services.
        </p>
        <p>
            We pride ourselves on personalized attention, clear communication, and results-driven strategies. Whether you're facing a legal challenge or planning for your future, we’re here to guide you with integrity and precision.
        </p>
        <p>
            At Cypress Law Group, our mission is to simplify the legal process and stand by your side every step of the way.
        </p>
    </section>
    <section class="lawyer-profiles">
        <h2>Our Attorneys</h2>
        <div class="lawyer-grid">
            <?php
            $attorneys = new WP_Query(array(
                'post_type' => 'attorney',
                'posts_per_page' => -1,
                'orderby' => 'title',
                'order' => 'ASC'
            ));

            if ($attorneys->have_posts()) :
                while ($attorneys->have_posts()) : $attorneys->the_post();
            ?>
                    <div class="lawyer-card">
                        <div>
                            <?php if (has_post_thumbnail()) : ?>
                                <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title(); ?> headshot">
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3><?php the_title(); ?></h3>
                            <p><?php the_content(); ?></p>
                        </div>
                    </div>
            <?php endwhile;
                wp_reset_postdata();
            endif; ?>
        </div>
    </section>

</main>

<?php get_footer(); ?>