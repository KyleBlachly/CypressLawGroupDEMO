<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> Cypress Law Group</p>
</footer>
<?php wp_footer(); ?>
</body>

</html>