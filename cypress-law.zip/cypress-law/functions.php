<?php

function cypresslaw_enqueue_assets()
{
    wp_enqueue_style('cypresslaw-style', get_stylesheet_uri());

    // FullCalendar v5.11.3 (CORRECT)
    wp_enqueue_style('fullcalendar-css', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css');
    wp_enqueue_script('fullcalendar-js', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js', array(), null, true);

    // Your custom JS
    wp_enqueue_script('cypresslaw-main', get_template_directory_uri() . '/main.js', array('fullcalendar-js'), false, true);
}
add_action('wp_enqueue_scripts', 'cypresslaw_enqueue_assets');


// Register Attorney Custom Post Type
function register_lawyer_cpt()
{
    register_post_type('attorney', array(
        'labels' => array(
            'name' => 'Attorneys',
            'singular_name' => 'Attorney',
            'add_new' => 'Add New Attorney',
            'add_new_item' => 'Add New Attorney',
            'edit_item' => 'Edit Attorney',
            'new_item' => 'New Attorney',
            'view_item' => 'View Attorney',
            'search_items' => 'Search Attorneys',
            'not_found' => 'No attorneys found',
            'not_found_in_trash' => 'No attorneys found in trash',
            'menu_name' => 'Attorneys'
        ),
        'public' => true,
        'menu_icon' => 'dashicons-businessman',
        'has_archive' => false,
        'rewrite' => array('slug' => 'attorney'),
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true
    ));
}
add_action('init', 'register_lawyer_cpt');

add_theme_support('post-thumbnails');
