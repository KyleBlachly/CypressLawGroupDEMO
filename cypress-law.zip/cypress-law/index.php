<?php
/* 
Template Name: Home
*/
?>

<?php get_header(); ?>

<main>
    <section class="hero">
        <h1>Welcome to Cypress Law Group</h1>
        <p>Trusted legal support with a modern approach.</p>
        <a href="/schedule" class="btn">Schedule a Consultation</a>
    </section>
</main>

<?php get_footer(); ?>