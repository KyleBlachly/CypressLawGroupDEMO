document.addEventListener("DOMContentLoaded", function () {
  const contactForm = document.getElementById("contact-form");
  const popup = document.getElementById("email-popup");
  const scheduleForm = document.getElementById("schedule-form");
  const schedulePopup = document.getElementById("schedule-popup");
  const scheduleDateDropdown = document.getElementById("schedule-date");
  const eventModal = document.getElementById("event-modal");
  const modalCloseBtn = document.getElementById("modal-close");
  const filterButtons = document.querySelectorAll("#admin-filters button");

  let currentFilter = "All";

  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = document.getElementById("contact-name").value;
      const email = document.getElementById("contact-email").value;
      const message = document.getElementById("contact-message").value;

      const preview = `
          <strong>Name:</strong> ${name}<br>
          <strong>Email:</strong> ${email}<br>
          <strong>Message:</strong><br>${message.replace(/\n/g, "<br>")}
        `;

      document.getElementById("email-preview").innerHTML = preview;
      popup.style.display = "flex";
    });
  }

  window.closePopup = function () {
    popup.style.display = "none";
    if (contactForm) contactForm.reset();
  };

  // Populate weekday dates (next 14 weekdays)
  if (scheduleDateDropdown) {
    const today = new Date();
    let added = 0;
    let date = new Date();

    while (added < 14) {
      const day = date.getDay();
      if (day !== 0 && day !== 6) {
        // Not Sunday (0) or Saturday (6)
        const option = document.createElement("option");
        option.value = getLocalDateString(date);
        option.text = date.toDateString();
        scheduleDateDropdown.appendChild(option);
        added++;
      }
      date.setDate(date.getDate() + 1);
    }
  }

  // Handle form submission
  if (scheduleForm) {
    scheduleForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = document.getElementById("schedule-name").value;
      const date = document.getElementById("schedule-date").value;
      const time = document.getElementById("schedule-time").value;
      const details = document.getElementById("schedule-details").value;

      const appointment = {
        name,
        date,
        time,
        details,
        status: "New",
        assignedTo: "None",
      };

      let appointments = JSON.parse(localStorage.getItem("appointments")) || [];
      appointments.push(appointment);
      localStorage.setItem("appointments", JSON.stringify(appointments));

      schedulePopup.style.display = "flex";
      scheduleForm.reset();
    });
  }

  function getApprovedAppointments() {
    const appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    return appointments.filter((a) => a.status === "Approved");
  }

  function disableTakenTimesForDate(selectedDate) {
    const approvedAppointments = getApprovedAppointments();
    const takenTimes = approvedAppointments
      .filter((app) => app.date === selectedDate)
      .map((app) => app.time);

    const timeDropdown = document.getElementById("schedule-time");
    const options = timeDropdown.querySelectorAll("option");

    options.forEach((option) => {
      if (takenTimes.includes(option.value)) {
        option.disabled = true;
        option.textContent = `${option.value} (unavailable)`;
      } else {
        option.disabled = false;
        option.textContent = option.value;
      }
    });
  }

  if (scheduleDateDropdown) {
    scheduleDateDropdown.addEventListener("change", function () {
      disableTakenTimesForDate(this.value);
    });

    if (scheduleDateDropdown.value) {
      disableTakenTimesForDate(scheduleDateDropdown.value);
    }
  }

  window.closeSchedulePopup = function () {
    schedulePopup.style.display = "none";
  };

  function getLocalDateString(date) {
    const offset = date.getTimezoneOffset();
    const localDate = new Date(date.getTime() - offset * 60000);
    return localDate.toISOString().split("T")[0];
  }

  // Filter Appointment
  function renderAppointments(filter) {
    if (!filter) {
      filter = currentFilter;
    } else {
      currentFilter = filter;
    }

    const calendarDiv = document.getElementById("calendar");
    const appointmentList = document.getElementById("appointment-list");

    const list = document.getElementById("appointment-list");
    if (!list) return;

    appointmentList.style.display = "block";
    calendarDiv.style.display = "none";

    const appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    list.innerHTML = "";

    const filtered = appointments.filter(
      (app) => filter === "All" || app.status === filter
    );

    if (filtered.length === 0) {
      list.innerHTML = "<p>No appointments found.</p>";
      return;
    }

    function formatDate(dateStr) {
      if (!dateStr) return "";

      const [year, month, day] = dateStr.split("-").map(Number);
      const date = new Date(year, month - 1, day);

      return date.toLocaleDateString("en-US", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
      }); // Example: "Tue, Apr 23, 2025"
    }

    filtered.forEach((app) => {
      const appointmentIndex = appointments.indexOf(app);

      const card = document.createElement("div");
      card.className = "appointment-card";

      card.innerHTML = `
    <h3>${app.name}</h3>
    <p><strong>Date:</strong> ${formatDate(app.date)}</p>
    <p><strong>Time:</strong> ${app.time}</p>
    <p><strong>Status:</strong> <span id="status-${appointmentIndex}">${
        app.status
      }</span></p>
    <p><strong>Assigned to:</strong> <span id="assigned-${appointmentIndex}">${
        app.assignedTo
      }</span></p>
    <p><strong>Details:</strong> ${app.details}</p>

    <div class="admin-controls">
      <select id="assign-${appointmentIndex}">
        <option value="">Assign Attorney</option>
        <option value="Michael Hartman">Michael Hartman</option>
        <option value="Elena Rivera">Elena Rivera</option>
        <option value="James Okoye">James Okoye</option>
      </select>
      <button onclick="updateAppointment(${appointmentIndex}, 'Approved')">Approve</button>
      <button onclick="updateAppointment(${appointmentIndex}, 'Denied')">Deny</button>
      ${
        app.status === "Denied"
          ? `<button class="delete-btn" onclick="deleteAppointment(${appointmentIndex})">Delete</button>`
          : ""
      }
    </div>
  `;
      list.appendChild(card);
    });
  }

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      filterButtons.forEach((btn) => btn.classList.remove("active")); // remove active from all
      button.classList.add("active"); // add to the clicked one
    });
  });

  window.filterAppointments = renderAppointments;

  window.updateAppointment = function (index, status) {
    const appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    const assigned = document.getElementById(`assign-${index}`).value || "None";

    if (status === "Approved" && assigned === "None") {
      alert("Please assign an attorney before approving this appointment.");
      return;
    }

    appointments[index].status = status;
    appointments[index].assignedTo = assigned;

    localStorage.setItem("appointments", JSON.stringify(appointments));
    renderAppointments();
  };

  window.deleteAppointment = function (index) {
    if (
      confirm("Are you sure you want to permanently delete this appointment?")
    ) {
      let appointments = JSON.parse(localStorage.getItem("appointments")) || [];
      appointments.splice(index, 1);
      localStorage.setItem("appointments", JSON.stringify(appointments));
      renderAppointments();
    }
  };

  // Calendar toggle
  window.toggleCalendar = function () {
    const calendarDiv = document.getElementById("calendar");
    const appointmentList = document.getElementById("appointment-list");
    if (calendarDiv.style.display === "none") {
      calendarDiv.style.display = "block";
      appointmentList.style.display = "none";
      setTimeout(() => {
        loadCalendar();
      }, 0);
    } else {
      calendarDiv.style.display = "none";
      appointmentList.style.display = "block";
    }
  };

  function loadCalendar() {
    const appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    const calendarEl = document.getElementById("calendar");

    calendarEl.innerHTML = "";

    const calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: "dayGridMonth",
      events: appointments
        .filter((app) => app.status === "Approved")
        .map((app, index) => ({
          id: String(index),
          title: app.name + " @ " + app.time,
          start: app.date,
          allDay: true,
          color: "#3a6b52",
          extendedProps: {
            appointmentData: app,
          },
        })),
      eventClick: function (info) {
        const appointment = info.event.extendedProps.appointmentData;

        if (appointment) {
          const modal = document.getElementById("event-modal");
          modal.style.display = "flex";
          void modal.offsetWidth;
          modal.classList.add("show");

          document.getElementById("modal-title").textContent = appointment.name;
          document.getElementById("modal-time").textContent =
            "Time: " + appointment.time;
          document.getElementById("modal-assigned").textContent =
            appointment.assignedTo;
          document.getElementById("modal-details").textContent =
            appointment.details;
        }
      },
    });

    calendar.render();
  }

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener("click", function () {
      eventModal.classList.remove("show");
    });
  }

  eventModal.addEventListener("click", function (e) {
    if (e.target === eventModal) {
      eventModal.classList.remove("show");
    }
  });

  renderAppointments();
});
