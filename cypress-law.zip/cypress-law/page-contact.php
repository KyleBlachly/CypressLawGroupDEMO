<?php
/*
Template Name: Contact Page
*/
get_header();
?>

<main class="contact-page">
    <h1>Contact</h1>
    <p>If you have questions or would like to learn more about our legal services, feel free to reach out using the form below.</p>

    <form id="contact-form">
        <label for="contact-name">Your Name</label>
        <input type="text" id="contact-name" name="contact-name" required>

        <label for="contact-email">Your Email</label>
        <input type="email" id="contact-email" name="contact-email" required>

        <label for="contact-message">Message</label>
        <textarea id="contact-message" name="contact-message" rows="5" required></textarea>

        <button type="submit" class="btn">Send Message</button>
    </form>

    <div id="email-popup" class="email-popup" style="display: none;">
        <div class="popup-content">
            <h2>Email Sent!</h2>
            <p><em>(For demo purposes, you can only see the email here)</em></p>
            <div id="email-preview"></div>
            <button onclick="closePopup()" class="btn">Close</button>
        </div>
    </div>
</main>

<?php get_footer(); ?>