<?php
/*
Template Name: Admin Dashboard
*/
get_header();
?>

<main class="dashboard-page">
    <h1>Admin Dashboard</h1>

    <div id="admin-filters">
        <button onclick="filterAppointments('All')">All</button>
        <button onclick="filterAppointments('New')">New</button>
        <button onclick="filterAppointments('Approved')">Approved</button>
        <button onclick="filterAppointments('Denied')">Denied</button>
        <button onclick="toggleCalendar()">Calendar</button>
    </div>

    <div class="appointment-list" id="appointment-list">

    </div>
    <div class='calendar' id="calendar" style="height: 800px;"></div>

    <div id="event-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span id="modal-close" class="modal-close">&times;</span>
            <h2 id="modal-title"></h2>
            <p id="modal-time"></p>
            <div class="modal-flex">
                <h3>Assigned To:</h3>
                <p id="modal-assigned"></p>
            </div>
            <div class="modal-flex">
                <h3>Details:</h3>
                <p id="modal-details"></p>
            </div>
        </div>
    </div>




</main>

<?php get_footer(); ?>