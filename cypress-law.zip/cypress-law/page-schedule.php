<?php
/*
Template Name: Schedule Page
*/
get_header();
?>

<main class="schedule-page">
    <h1>Schedule a Consultation</h1>
    <form id="schedule-form">
        <label for="schedule-name">Your Name</label>
        <input type="text" id="schedule-name" name="schedule-name" maxlength="55" required>

        <label for="schedule-date">Date</label>
        <select id="schedule-date" name="schedule-date" required></select>

        <label for="schedule-time">Time</label>
        <select id="schedule-time" name="schedule-time" required>
            <option value="8:00 AM">8:00 AM</option>
            <option value="10:00 AM">10:00 AM</option>
            <option value="1:00 PM">1:00 PM</option>
            <option value="3:00 PM">3:00 PM</option>
        </select>

        <label for="schedule-details">Details</label>
        <textarea id="schedule-details" name="schedule-details" maxlength="200" required rows="3"></textarea>

        <button type="submit" class="btn">Submit</button>
    </form>

    <div id="schedule-popup" class="email-popup" style="display:none;">
        <div class="popup-content">
            <h2>Thank you for scheduling with us</h2>
            <p>Your appointment is under review.</p>
            <button onclick="closeSchedulePopup()" class="btn">Close</button>
        </div>
    </div>
</main>

<?php get_footer(); ?>